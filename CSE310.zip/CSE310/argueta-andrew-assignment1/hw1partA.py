import dns.query
import time
def dns_resolver():
    domain = input('mydig ') #prompting the user to type in a domain
    domain = domain.strip() #stripping whitespaces

    start_time = time.time() #starting time for query response time
    request = time.localtime() #time and date of request
    domain_query = dns.message.make_query(domain, dns.rdatatype.A) #making a query to send out
    root_query = dns.query.udp(domain_query,"198.41.0.4") #sending query to VeriSign IP address
    domain_extension = domain.split('.')[-1] #getting the '.com' '.org' '.net' etc.
    rr_set_authority = root_query.find_rrset(root_query.authority, dns.name.from_text(domain_extension +'.'), dns.rdataclass.IN,
                                             dns.rdatatype.NS) #rr set to find the next IP address
    if(not root_query.additional): #if theres no additional
        return
    else:
        for rdata in root_query.additional: #loop until the name from additional matches authority
            if str(rdata.name) == str(rr_set_authority[0]):
                root_ip_address = rdata[0] #set ip address to matching authority field
                break


    tld_query = dns.query.udp(domain_query, str(root_ip_address),5) #sending query to found IP address

    if (not tld_query.additional): #if theres no additional field do a seperate search
        domain = str(tld_query.authority[0][0])
        domain_query = dns.message.make_query(domain, dns.rdatatype.A)
        root_query = dns.query.udp(domain_query, "198.41.0.4")  # VeriSign IP address
        domain_extension = domain.split('.')[-2]
        rr_set_authority = root_query.find_rrset(root_query.authority, dns.name.from_text(domain_extension + '.'),dns.rdataclass.IN,
                                                 dns.rdatatype.NS)
        for rdata in root_query.additional:
            if str(rdata.name) == str(rr_set_authority[0]):
                root_ip_address = rdata[0]
                break

        tld_query = dns.query.udp(domain_query, str(root_ip_address), 5)
        split_r_data = str(tld_query.authority[0]).split('\n')
        for rdata in split_r_data:
            if len(tld_query.additional) > 1:
                if str(rdata.split(' ')[4]) == str(tld_query.additional[0].name):
                    tld_ip_address = tld_query.additional[0][0]
                    break
            else:
                if str(rdata.split(' ')[4]) == str(tld_query.additional[0].name):
                    tld_ip_address = tld_query.additional[1][0]
                    break
    else: #else get the ip address the same way we got it in the first search
        split_r_data = str(tld_query.authority[0]).split('\n')
        for rdata in split_r_data:
            if len(tld_query.additional) > 1:
                if str(rdata.split(' ')[4]) == str(tld_query.additional[1].name): #this is to skip maitenance pages
                    tld_ip_address = tld_query.additional[1][0]
            else:
                if str(rdata.split(' ')[4]) == str(tld_query.additional[0].name):
                    tld_ip_address = tld_query.additional[0][0]

    authoritative_query = dns.query.udp(domain_query, str(tld_ip_address),5) #sending query to authoritative IP address
    #QUESTION SECTION
    print("QUESTION SECTION:")
    elapsed_time = time.time()- start_time #total time for all the queries to be sent and sent back
    for rdata in authoritative_query.question:
        print(rdata) #printing all the fields in question
        print()
    #ANSWER SECTION
    print("ANSWER SECTION:")
    for rdata in authoritative_query.answer:
        print(rdata) #printing all the fields in answer
    elapsed_time*=1000 #converting to ms
    print()
    print("Query Time: " + "{:4.2f}".format(elapsed_time) + " ms") #printing query response time
    print()
    print("WHEN: " + time.asctime(request)) #printing date reqeust
dns_resolver()