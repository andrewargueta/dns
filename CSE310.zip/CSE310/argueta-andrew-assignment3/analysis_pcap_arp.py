import dpkt


class ARP_Packet:
    def __init__(this):
        this.hardware_type = 0
        this.protocol_type = 0
        this.hardware_size = 0
        this.protocol_size = 0
        this.opcode = 0
        this.sender_mac_address=""
        this.sender_ip_address = ""
        this.target_mac_address = ""
        this.target_ip_address = ""

def decimal2hex(int):
    return hex(int).replace("0x","")

def analysis_pcap_arp(pcap_file):
    arp_packets =[]
    cnt_arp = 0
    decimal2hex(1)
    protocol_types={
        0x800 : "IPv4",
        0x806 : "Address Resolution",
        0x88a2: "AoE Protocol",
        0x200: "PUP Protocol",
        0x86dd: "IPv6",
        0x0:"Unknownn",
        0x2000: "Cisco Discovery Protocol",
        0x2004: "Cisco Dynamic Trunking Protocol"
    }
    for timestamp, buffer in dpkt.pcap.Reader(open(pcap_file, 'rb')):

        #index 0:5 -> dest addr
        #index 6:11 -> src addr
        #indexes 12 & 13 -> tells you if ARP or not
        #indexes 14 & 15 -> hardware type
        #indexes 16 & 17 -> protocol type
        #index 18 -> hardware size
        #index 19 -> protocol size
        #index 20 & 21 -> opcode
        #index 22:27 -> sender mac address
        #index 28:31 -> sender ip address
        #index 32:37 -> target mac address
        #index 38:41 ->target ip address

        is_arp = buffer[12].to_bytes(1, 'big')
        is_arp += buffer[13].to_bytes(1,'big')

        if(int.from_bytes(is_arp, 'big') == dpkt.ethernet.ETH_TYPE_ARP ):
            cnt_arp +=1
            hardware_type = buffer[14].to_bytes(1, 'big')
            hardware_type += buffer[15].to_bytes(1, 'big')
            hardware_type = int.from_bytes(hardware_type, 'big')

            protocol_type = buffer[16].to_bytes(1, 'big')
            protocol_type += buffer[17].to_bytes(1, 'big')
            protocol_type = int.from_bytes(protocol_type, 'big')

            hardware_size = buffer[18]

            protocol_size = buffer[19]

            opcode = buffer[20].to_bytes(1, 'big')
            opcode += buffer[21].to_bytes(1, 'big')
            opcode = int.from_bytes(opcode, 'big')

            sender_mac_address = decimal2hex(buffer[22]) + '.'
            sender_mac_address += decimal2hex(buffer[23]) + '.'
            sender_mac_address += decimal2hex(buffer[24]) + '.'
            sender_mac_address += decimal2hex(buffer[25]) + '.'
            sender_mac_address += decimal2hex(buffer[26]) + '.'
            sender_mac_address += decimal2hex(buffer[27])

            sender_ip_address = str(buffer[28]) +'.'
            sender_ip_address += str(buffer[29])+'.'
            sender_ip_address += str(buffer[30])+'.'
            sender_ip_address += str(buffer[31])

            target_mac_address = decimal2hex(buffer[32]) + '.'
            target_mac_address += decimal2hex(buffer[33]) + '.'
            target_mac_address += decimal2hex(buffer[34]) + '.'
            target_mac_address += decimal2hex(buffer[35]) + '.'
            target_mac_address += decimal2hex(buffer[36]) + '.'
            target_mac_address += decimal2hex(buffer[37])

            target_ip_address = str(buffer[38]) + '.'
            target_ip_address += str(buffer[39]) + '.'
            target_ip_address += str(buffer[40]) + '.'
            target_ip_address += str(buffer[41])

            packet = ARP_Packet()
            packet.hardware_type = hardware_type
            packet.protocol_type = protocol_type
            packet.hardware_size = hardware_size
            packet.protocol_size = protocol_size
            packet.opcode = opcode
            packet.sender_mac_address = sender_mac_address
            packet.sender_ip_address = sender_ip_address
            packet.target_ip_address = target_ip_address
            packet.target_mac_address = target_mac_address
            arp_packets.append(packet)

        else:
            continue


    print()
    print("Number of ARP packets captured: " + str(cnt_arp))
    print()
    print("-----------------ARP REQUEST-----------------")
    req_arp = ARP_Packet()
    for i in arp_packets:
        if i.opcode == 1:
            print("Hardware Type: " + str(i.hardware_type))
            print("Protocol Type: " + protocol_types.get(i.protocol_type) + " (" + str(hex(i.protocol_type)) + ")")
            print("Hardware Size: " + str(i.hardware_size))
            print("Protocol Size: " + str(i.protocol_size))
            print("Opcode: " + str(i.opcode))
            print("Sender MAC Address: " + str(i.sender_mac_address))
            print("Sender IP Address: " + str(i.sender_ip_address))
            print("Target MAC Address: " + str(i.target_mac_address))
            print("Target IP Address: " + str(i.target_ip_address))
            req_arp = i
            break
    print()
    print("-----------------ARP RESPONSE-----------------")
    for i in arp_packets:
        if (i.target_ip_address == req_arp.sender_ip_address) and (i.target_mac_address == req_arp.sender_mac_address)\
                and (i.opcode == 2):
            print("Hardware Type: " + str(i.hardware_type))
            print("Protocol Type: " + protocol_types.get(i.protocol_type) + " (" + str(hex(i.protocol_type)) + ")")
            print("Hardware Size: " + str(i.hardware_size))
            print("Protocol Size: " + str(i.protocol_size))
            print("Opcode: " + str(i.opcode))
            print("Sender MAC Address: " + str(i.sender_mac_address))
            print("Sender IP Address: " + str(i.sender_ip_address))
            print("Target MAC Address: " + str(i.target_mac_address))
            print("Target IP Address: " + str(i.target_ip_address))
            break


analysis_pcap_arp("assignment3.pcap")