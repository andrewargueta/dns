import dpkt

class Flow:
    def __init__(this, src, dst):
        this.src_port = src
        this.dst_port = dst
        this.packets = [] #packets in each flow
        this.timestamp =[]
        this.payload = 0
        this.RTT = 0
        this.congested_windows=[]
    def calculate_RTT(this):
        first_packet = this.packets[4][0] #packet after handshake
        for i in range(4,len(this.packets)): #looking for the matching ack
            if this.packets[i][0].ack == first_packet.seq:
                this.RTT = (this.packets[i][1]-this.packets[4][1] ) #time diff between the 2


    def init_congested_windows(this):
        this.calculate_RTT() #getting the RTT window
        first_packet_timestamp = this.packets[1][1]
        counter = 1 #1 packet is already sent
        for i in range(1, len(this.packets)): #looping to see how many packets are sent during RTT
            counter += 1
            if ((this.packets[i][1] - first_packet_timestamp) > this.RTT): #if its greater than RTT than thw window is congested
                this.congested_windows.append(counter) #appending how many packets were sent
                counter=1 #resetting counter
                first_packet_timestamp = this.packets[i][1] #starting off at the most recent packet sent


    def duplicate_acks(this):
        acks = {}
        dups = 0
        for p in this.packets:
            acks[p[0].ack] = 0 #setting all ack values to 0
        for p in this.packets:
            acks[p[0].ack] += 1 #how many times an ack is sent to the sender
        for key in acks:
            if acks[key] > 2: #if its greater than 2 than the ack has been under triple dup
                dups += 1
        return dups


    def rto(this):
        #same logic as duplicate acks except were looking for values  that  == 2
        acks = {}
        rto = 0
        for p in this.packets:
            acks[p[0].ack] = 0
        for p in this.packets:
            acks[p[0].ack] += 1
        for key in acks:
            if acks[key] == 2:
                rto += 1
        return rto


def analysis_pcap_tcp(pcap_file):
    num_of_flows = 0 #number of flows that were opened up
    flows=[] #keeping track of flows
    window_size = 0
    for timestamp, buffer in dpkt.pcap.Reader(open(pcap_file, 'rb')):
        #for loop to identify how many connections are there
        eth = dpkt.ethernet.Ethernet(buffer)
        ip = eth.data
        if ip.p != dpkt.ip.IP_PROTO_TCP:
            #if its not TCP ignore
            continue
        tcp = ip.data
        if ((tcp.flags & dpkt.tcp.TH_SYN) and (tcp.flags & dpkt.tcp.TH_ACK)): #if packet is SYN,ACK then its opening up a connection
            num_of_flows += 1 #adding to num_connections
            flow = Flow(tcp.sport,tcp.dport)  #making a flow object
            flows.append(flow) #adding to the flows
        for opt in dpkt.tcp.parse_opts(tcp.opts):
            #finding wscale
            if opt[0] == dpkt.tcp.TCP_OPT_WSCALE:
                window_size = ord(opt[1]) #literal to int
                window_size = 2 ** window_size #scaling factor =  2^(wscale)



    for flow in flows:
        i = 0
        #matching each packet to the corresponding flow
        for timestamp, buffer in dpkt.pcap.Reader(open(pcap_file, 'rb')):
            eth = dpkt.ethernet.Ethernet(buffer)
            ip = eth.data
            tcp = ip.data
            if ip.p != dpkt.ip.IP_PROTO_TCP:
                continue
            if ((flow.src_port == tcp.sport and flow.dst_port == tcp.dport) or (flow.src_port == tcp.dport and flow.dst_port == tcp.sport)):
                i+=1
                flow.packets.append((tcp, timestamp))  # if packet is the same ports as the flow then it belongs to that flow
                if i>4:
                    #after Handshake start adding to its total amount of data
                    flow.payload += len(buffer)


    print("Number of TCP Flows: " +  str(num_of_flows))
    print()
    flow_num = 1
    for flow in flows:
        print("Flow #"+str(flow_num))
        print("==========================================================================")
        print("Packet #1 (Sent) ----- Ack: " + str(flow.packets[4][0].ack)+(" ----- Seq: " + str(flow.packets[4][0].seq))
              + " ----- Window Size (scaled): " + str(flow.packets[4][0].win * window_size))

        for p in flow.packets:
            if p[0].ack == flow.packets[4][0].seq:
                recieved = p
        print("Packet #1 (Corresponding Ack) ----- Ack: " + (str(recieved[0].ack)) + (
        " ----- Seq: " +str(recieved[0].seq))
              + " ----- Window Size (scaled): " + str(recieved[0].win * window_size))
        print()
        print("Packet #2 (Sent) ----- Ack: " + str(flow.packets[5][0].ack) + (
        " ----- Seq: " + str(flow.packets[5][0].seq))
              + " ----- Window Size (scaled): " + str(flow.packets[5][0].win * window_size))
        for p in flow.packets:
            if p[0].ack == flow.packets[5][0].seq:
                recieved = p
        print("Packet #2 (Corresponding Ack) ----- Ack: " + (str(recieved[0].ack)) + (
            " ----- Seq: " + str(recieved[0].seq))
              + " ----- Window Size (scaled): " + str(recieved[0].win *window_size))

        print()
        print("Total Throughput: " + str(flow.payload / (flow.packets[-1][1] - flow.packets[0][1])) + " bits per second")
        flow.calculate_RTT()
        print("Calculated RTT: "+ str(flow.RTT) + " seconds")
        flow.init_congested_windows()
        print("Congestion Window Sizes: " + str(flow.congested_windows[0:5]))
        print("# of Retransmissions due to Duplicate Acks: " + str(flow.duplicate_acks()))
        print("# of Retransmissions due to Timeouts: " + str(flow.rto()))
        print()

        flow_num+=1


analysis_pcap_tcp("assignment2.pcap")